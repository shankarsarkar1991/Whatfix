//Google Tag Manager
	(function(w, d, s, l, i) {
		var _wfx_amplitude_api_key = "710c8418e5d8c25f0566d8be33182fab";
		w['_wfx_global_properties'] = null;
		w['_wfx_user_id'] = null;
	    w[l] = w[l] || [];
	    w[l].push({
	        'gtm.start': new Date().getTime(),
	        event: 'gtm.js',
	        'amp_id': _wfx_amplitude_api_key
	    });
	    var f = d.getElementsByTagName(s)[0],
	        j = d.createElement(s),
	        dl = l != 'dataLayer' ? '&l=' + l : '';
	    j.async = true;
	    j.src =
	        'https://www.googletagmanager.com/gtm.js?id=' + i + dl + '&gtm_auth=jeID3lkpaVneJ1EWrSn0Uw&gtm_preview=env-2&gtm_cookies_win=x';
	    f.parentNode.insertBefore(j, f);
	})(window, document, 'script', 'dataLayer', 'GTM-P54B6ZF');
	// End Google Tag Manager