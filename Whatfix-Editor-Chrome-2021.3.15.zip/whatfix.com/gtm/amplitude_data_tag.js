function getAttribute(attr_name) {
	return dataLayer[dataLayer.length - 1]['gtm.element'].attributes[attr_name].value;
}
var eventProperties = {
	'module' : 'editor'
};
if (typeof amplitude !== 'undefined') {
	var element = dataLayer[dataLayer.length - 1]['gtm.element'];
	if(element.tagName.toLowerCase() == 'select'){
		eventProperties.selectedValue = element.options[element.selectedIndex].innerHTML;
	}
	else if (element.type == 'radio'){
		eventProperties.selectedValue = element.labels[0].innerHTML;
	}
	if(window._wfx_global_properties){
		amplitude.setUserProperties(window._wfx_global_properties);
	}
	amplitude.getInstance().logEvent(getEvent(getAttribute('data-wfx-attr')), eventProperties);
}