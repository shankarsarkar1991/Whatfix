window._wfx_settings= window._wfx_settings || {};
window._wfx_settings.disable_popup_actioncomplete = true;

window._wfx_settings = window._wfx_settings || {};


//refresh the cookies everytime new tab is opened
sessionStorage.userid = window._wfx_settings.user = (sessionStorage.userid || (new Date()).getTime()) + "";

function checkSmartTipData (event){
  console.log("inside add listener");
  event.preventDefault();
  window._wfx_smartTipLive = "true";
  _wfx_refresh();
}

window._wfx_smartTipLive = "false";
//var clickAmountInterval= setInterval (function(){
if (document.querySelector("[name='company']").value.length==0){
  document.querySelector("#wpcf7-f1039-o1 > form > div:nth-child(3) > div > input").addEventListener("click",checkSmartTipData,false);
}

document.querySelector("[name='company']").addEventListener("mouseover", function(event){
  console.log("inside remove listener 1");
 if (document.querySelector("[name='company']").value.length>=1){
 document.querySelector("#wpcf7-f1039-o1 > form > div:nth-child(3) > div > input").removeEventListener("click",checkSmartTipData,false);
}
});
//},1000);

// Use Case: stop a button click to launch content instead.
// After interacting with the content, allow the button to be clicked
/*var _wfx_smartTipLive = false;
var buttonClicksAmount = new Map();
var buttonsGroupSelector = "<THIS TO BE REPLACED>"; // this value to be replaced with the CSS selector that brings an array of all the relevant buttons
var clickAmountInterval = setInterval(function (){
var elemArr = document.querySelectorAll("#wpcf7-f1039-o1 > form > div:nth-child(3) > div > input");
  if (elemArr != null && elemArr.length >= 1)
  	{
      for (var i = 0; i < elemArr.length; i++)
        {
          buttonClicksAmount.set(elemArr[i], 0);
      elemArr[i].addEventListener("click", handleOneTimeClick, false);
      //elemArr[i].addEventListener("mousedown", handleOneTimeClick, false);
      console.log("after adding event listener - in clicks interval");
      clearInterval(clickAmountInterval);
      console.log("clicks interval cleared. elem is still: " + elemArr[i].tagName);
        }
	}
}, 500);

function handleOneTimeClick (ev)
{
  console.log("in handleonetimeclick");
  _wfx_smartTipLive = false;
  var currVal = buttonClicksAmount.get(this);
  console.log(currVal);
  currVal++;
  if (currVal == 1 && document.querySelector("[name='company']").value.length==0 && _wfx_smartTipLive == false)
    {
      console.log("clicked once!");
      stopEvent(ev);
      // launch a popup/tip
      _wfx_smartTipLive = true;
      _wfx_refresh();
    }
  else
    {
      _wfx_smartTipLive = false;
    }
  buttonClicksAmount.delete(this);
  buttonClicksAmount.set(this, currVal);
}

function stopEvent(ev) {
  console.log("in stopEvent");
  ev.preventDefault();
  ev.stopImmediatePropagation(); 
  ev.stopPropagation();
  console.log("event propagation halted.");
}*/

/*var firstTimePopup = false;

if (window.localStorage &&
!window.localStorage.getItem('tour')) {
       window.localStorage.setItem('tour','yes');
  		firstTimePopup= true;
}*/

/*var smartTipVal = "false";
var smartTipFlowId= "c9cc6410-9162-11eb-a14e-2a8342861064";*/

/*window._wfx_settings.onShow = function(event){
    //identify the flow
  	console.log(smartTipVal);
    if(event.flow_id ==smartTipFlowId && event.step == "4"){
    if(document.querySelector("#wpcf7-f1039-o1 > form > div:nth-child(2) > div:nth-child(1) > div:nth-child(4) > span > input").value != "shankar.sarkar@whatfix.com"){
    smartTipVal = "true";
  	console.log(smartTipVal);
    _wfx_refresh();
    }
    }
};*/

/*function checkValue(inText)
{
console.log("in checkValue. inText: " + inText);
var retVal = false;
var email_field = document.querySelector("#wpcf7-f1039-o1 > form > div:nth-child(2) > div:nth-child(1) > div:nth-child(4) > span > input").value == "shankar.sarkar@whatfix.com";
console.log("email_field = " + email_field);
return email_field;
}

window._wfx_settings.onShow =  function onValidate(event) {
console.log("in onvalidation");
var result = {
isValid: true,
error: "Input Error"
};
if (event.flow_id == "efa9b070-9162-11eb-a14e-2a8342861064" && event.step == 1) {
console.log("in if condition to check right smart tip");
result.isValid = checkValue(event.input);
return result;
} else {
return null;
}
};*/