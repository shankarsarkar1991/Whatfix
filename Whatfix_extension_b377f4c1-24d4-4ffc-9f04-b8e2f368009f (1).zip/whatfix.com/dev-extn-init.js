let init_wfx = document.getElementById('init_dev');
let head_doc_wfx = document.getElementsByTagName('head');
if (head_doc_wfx && head_doc_wfx.length != 0 && init_wfx) {
    let script_wfx = document.createElement('script');
    //this is needed because in google csp error gets thrown,trusted type needs to be added to overcome that
    if (getCSPSanitizer()) {
        var sanitizer = trustedTypes.createPolicy('escapeRequireTrustedTypes', {
            createScriptURL: function(scriptUrl) {
                return scriptUrl;
            },
        });

        script_wfx.src = sanitizer.createScriptURL(init_wfx.getAttribute('wfx-dev-url'));
    } else {
        script_wfx.src = init_wfx.getAttribute('wfx-dev-url');
    }

    script_wfx.setAttribute('type', 'text/javascript');
    script_wfx.setAttribute('id', '_wfx_embed_injected_via_extension');
    script_wfx.setAttribute('stage', init_wfx.getAttribute('stage'));
    script_wfx.setAttribute('state', init_wfx.getAttribute('state'));
    script_wfx.setAttribute('json_message', init_wfx.getAttribute('json_message'));
    script_wfx.setAttribute('load-we-modules', init_wfx.getAttribute('load-we-modules'));
    head_doc_wfx[0].appendChild(script_wfx);
    init_wfx = null;
    head_doc_wfx = null;
}

function getCSPSanitizer() {
    return (
        window &&
        window.trustedTypes &&
        window.trustedTypes.createPolicy &&
        window.location &&
        window.location.hostname &&
        window.location.hostname.includes('google.com')
    );
}