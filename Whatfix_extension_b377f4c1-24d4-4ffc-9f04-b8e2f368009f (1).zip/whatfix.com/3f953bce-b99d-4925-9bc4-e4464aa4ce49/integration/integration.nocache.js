//initialize WFX AC
window._wfx_settings = window._wfx_settings || {};

//allow WFX flows to appear in popups even if the flow has been completed before
window._wfx_settings.disable_popup_actioncomplete = true;

//Single Page Application AC script
window._wfx_cp = location.href;setInterval(function() {if (window._wfx_cp != location.href) {window._wfx_cp = location.href;_wfx_refresh();}}, 500);

//register mousedown as click
_wfx_settings.action_events = ['touchstart','mousedown','click'];

//only copy till here by default - not the part below

//Animations in Self Help
_wfx_settings.closed_sh_notification_enable = true;