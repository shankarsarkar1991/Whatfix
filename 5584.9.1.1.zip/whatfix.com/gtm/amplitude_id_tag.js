var clickElement = dataLayer[dataLayer.length - 1]['gtm.element'];
var clickId = dataLayer[dataLayer.length - 1]['gtm.elementId'];
var eventProperties = {
	'module' : 'editor'
};

if (typeof amplitude !== 'undefined') {
	var element = clickElement
	if(element.tagName.toLowerCase() == 'select'){
		eventProperties.selectedValue = element.options[element.selectedIndex].innerHTML;
	}
	else if (element.type == 'radio'){
		eventProperties.selectedValue = element.labels[0].innerHTML;
	}
	if(window._wfx_editorType){
		eventProperties.editorType = window._wfx_editorType;
	}
	amplitude.setUserProperties(_wfx_global_properties);
	amplitude.getInstance().logEvent(getEvent(clickId), eventProperties);
}