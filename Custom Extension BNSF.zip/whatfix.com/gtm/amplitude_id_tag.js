var clickElement = dataLayer[dataLayer.length - 1]['gtm.element'];
var clickId = dataLayer[dataLayer.length - 1]['gtm.elementId'];
var eventProperties = {
	'module' : 'editor'
};

if (window.wfx_analytics) {
	var element = clickElement
	if(element.tagName.toLowerCase() == 'select'){
		eventProperties.selectedValue = element.options[element.selectedIndex].innerHTML;
	}
	else if (element.type == 'radio'){
		eventProperties.selectedValue = element.labels[0].innerHTML;
	}
	if(window._wfx_editorType){
		eventProperties.editorType = window._wfx_editorType;
	}

    let properties_pi, userID;
    if(window._wfx_global_properties){
    	properties_pi = window._wfx_global_properties;
    }
    if(window._wfx_user_name) {
    	userID = window._wfx_user_name;
    }

	window.wfx_analytics.send_event(
        getEvent(clickId),
        [userID],
        eventProperties,
        {},
        properties_pi
    );
}