function getAttribute(attr_name) {
	return dataLayer[dataLayer.length - 1]['gtm.element'].attributes[attr_name] && 
	dataLayer[dataLayer.length - 1]['gtm.element'].attributes[attr_name].value;
}
var eventProperties = {
	'module' : 'editor'
};
if (window.wfx_analytics) {
	var element = dataLayer[dataLayer.length - 1]['gtm.element'];
	if(element.tagName.toLowerCase() == 'select'){
		eventProperties.selectedValue = element.options[element.selectedIndex].innerHTML;
	}
	else if (element.type == 'radio'){
		eventProperties.selectedValue = element.labels[0].innerHTML;
	}
	let properties_pi;
	if(window._wfx_global_properties){
		properties_pi = window._wfx_global_properties;
	}
	if(window._wfx_editorType){
		eventProperties.editorType = window._wfx_editorType;
	}

	let userID;
	if(window._wfx_user_name) {
	    userID = window._wfx_user_name;
	}

    window.wfx_analytics.send_event(
        getEvent(getAttribute('data-wfx-attr')),
        [userID],
        eventProperties,
        {},
        properties_pi
    );
}