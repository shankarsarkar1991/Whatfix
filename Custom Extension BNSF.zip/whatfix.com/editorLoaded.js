window.__wfx_editor = true;

/*
Clearing two window variable for embed script re-injection.
Note: This will only work with Non-SSO ENTs
*/
window.addEventListener("message", function(msg){
    if(msg.data === "$#@remove_embed_instance:") {
        window.___embed = false;
        if(window.__gwt_activeModules) {
            window.__gwt_activeModules["editorembed"] = null;
        }
    }
});