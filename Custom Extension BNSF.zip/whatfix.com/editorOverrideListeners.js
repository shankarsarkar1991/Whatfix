try {
	if (!window.isWfxEntScriptLoaded) {
		window.isWfxEntScriptLoaded = true;
		var getStackTrace = function() {
			try {
				var obj = {};
				Error.captureStackTrace(obj, getStackTrace);
				return obj.stack;
			} catch(e) {
				return "";
			}
		};
	
		var isEventOneOfOurs = function(eventName) {
			return eventName.indexOf("mouse") > -1
					|| eventName.indexOf("touch") > -1
					|| eventName.indexOf("focus") > -1
					|| eventName.indexOf("blur") > -1
					|| eventName.indexOf("click") > -1
					|| eventName.indexOf("keydown") > -1;
		};
	
		var tooltipIds = [ "wfx-flow-tip", "wfx-smart-tip", "wfx-beacon-tip",
				"wfx-error-tip", "wfx-flow-tip-step-snap",
				"wfx-froala-container-main" ]
	
		function matchPath(event) {
			var isPathMatching = false;
			if (event && event.path && event.path.length) {
				for (var i = 0; i < event.path.length; i++) {
					var ele = event.path[i];
					var currentEleId = ele.id;
					if (tooltipIds.indexOf(currentEleId) > -1) {
						isPathMatching = true;
						break;
					}
				}
			}
			return isPathMatching;
		}
	
		var isFromOurOrigin = function() {
			var trace = getStackTrace();
			if (trace.split("/whatfix.com/").length > 3) {
				return true;
			}
			return false;
		};
	
		var _win_addEventListener = window.addEventListener;
		var _doc_addEventListener = window.document.addEventListener;
		var _body_addEventListener = window.document.body.addEventListener;
	
		var eventMappings = {
			win : {
				addListener : _win_addEventListener,
				removeListener : window.removeEventListener
			},
			doc : {
				addListener : _doc_addEventListener,
				removeListener : window.document.removeEventListener
			},
			body : {
				addListener : _body_addEventListener,
				removeListener : window.document.body.removeEventListener,
	
			}
		};
	
		window.wfxAction = window.wfxAction || {};
		window.wfxAction.getRemovaleEventsMappings = function() {
			return eventMappings;
		};
	
		function manipulateEvents(type) {
		  Object.keys(eventMappings).map(function (section) {
		    var currentSection = eventMappings[section];
		    if (Object.keys(currentSection).length) {
		      Object.keys(currentSection).map(function (currentEventKey) {
		        if (parseInt(currentEventKey)) {
		          var eventArgs = currentSection[currentEventKey];
		          var arrArgs = Array.from(eventArgs);
		          if (type === "remove") {
		            currentSection.removeListener.apply(
		              eventArgs[eventArgs.length],
		              arrArgs
		            );
		          } else if (type === "add") {
		            currentSection.addListener.apply(
		              eventArgs[eventArgs.length],
		              arrArgs
		            );
		          }
		        }
		      });
		    }
		  });
		}
	
		window.wfxAction.removeEvents = function() {
			manipulateEvents("remove");
		};
	
		window.wfxAction.addEvents = function() {
			manipulateEvents("add");
		};
	
		window.addEventListener = function() {
			if (isEventOneOfOurs(arguments[0]) && !isFromOurOrigin()) {
				var currentArguments = arguments;
				var index = Object.keys(eventMappings.win).length - 1;
				currentArguments[currentArguments.length] = this;
				eventMappings.win[index] = currentArguments;
			}
			_win_addEventListener.apply(this, arguments);
		};
	
		window.document.addEventListener = function() {
			if (isEventOneOfOurs(arguments[0]) && !isFromOurOrigin()) {
				var currentArguments = arguments;
				var index = Object.keys(eventMappings.doc).length - 1;
				currentArguments[currentArguments.length] = this;
				eventMappings.doc[index] = currentArguments;
			}
			_doc_addEventListener.apply(this, arguments);
		};
	
		window.document.body.addEventListener = function() {
			if (isEventOneOfOurs(arguments[0]) && !isFromOurOrigin()) {
				var currentArguments = arguments;
				var index = Object.keys(eventMappings.body).length - 1;
				currentArguments[currentArguments.length] = this;
				eventMappings.body[index] = currentArguments;
			}
			_body_addEventListener.apply(this, arguments);
		};
	}
}catch(e){console.log("editorOverrideListners - Exception", e);}