var _wfx_smt_icon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><defs><style>.wfx-cls-1{fill:#596377 !important;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="wfx-cls-1" d="M8,0a8,8,0,1,0,8,8A8,8,0,0,0,8,0ZM8,14.5A6.5,6.5,0,1,1,14.5,8,6.51,6.51,0,0,1,8,14.5Z"></path><path class="wfx-cls-1" d="M8,2.8A1.32,1.32,0,0,0,8,5.44,1.32,1.32,0,1,0,8,2.8Z"></path><path class="wfx-cls-1" d="M8.78,6.44H7.22a.36.36,0,0,0-.35.37v6a.37.37,0,0,0,.35.37H8.78a.37.37,0,0,0,.35-.37v-6A.36.36,0,0,0,8.78,6.44Z"></path></g></g></svg>`;

const _wfx_content_types = {
  FLOW: 'flow',
  TIP: 'tip',
  SMART_TIP: 'smart_tip',
  BEACON: 'beacon'
};

const _wfx_element_selectors = {
  EDITOR_IFRAME_ID: '#wfx-editor-iframe',
  TOOLTIP_WRAPPER_ID: '#wfx-editable-tooltip-wrapper',
  STUDIO_BEACON_CLASS: '.wfx-studio-new-beacon',
  TIP_INFO_ICON_CLASS: '.ico-information',
  STUDIO_BEACON_ID: "#wfx-studio-beacon-widget"
};

const _wfx_message_types = {
  REFRESH_TOOLTIP: 'refresh_tooltip'
};

const _wfx_beacon_animation_type = {
  RADIAL: 'radial',
  NEW: 'new',
  RIPPLE: 'ripple',
  SPECKLE: 'speckle'
}

const _wfx_beacon_width = {
  RADIAL: 24,
  NEW: 36,
  RIPPLE: 30,
  SPECKLE: 10
}

const _wfx_beacon_placements = ["rt", "rb", "lt", "lb"];
const _wfx_beacon_icon_width = 20;
const _wfx_beacon_icon_height = 20;
const _wfx_beacon_default_animation_width = 10;
const _wfx_beacon_default_animation_height = 24;
const _wfx_beacon_radial_animation_half_width = 12;

const _wfx_cross_messager = {
  sendMessage: function(targetWindow, type, content) {
    try {
      const crypty = '$#@', separator = ':';
      const message = crypty + type + separator + JSON.stringify(content);
      targetWindow.postMessage(message, '*');
    } catch {
    }
  }
};

const _wfx_corner_position_handler = {
  getLeftOverflowFixPlacement: function(placement) {
    const leftOverflowPositionsMap = new Map();
    leftOverflowPositionsMap.set("l", "r");
    leftOverflowPositionsMap.set("lb", "rb");
    leftOverflowPositionsMap.set("lt", "rt");
    return leftOverflowPositionsMap.get(placement)
  },
  refreshToolTipOnOverflow: function(newPlacement, iconLeft, iconTop, iconWidth, iconHeight) {
    const editorElement = window.top.document.querySelector(_wfx_element_selectors.EDITOR_IFRAME_ID);
    if (editorElement) {
      var cornerPositionAdjustment = {
        placement: newPlacement,
        left: iconLeft,
        top: iconTop,
        width: iconWidth,
        height: iconHeight
      };
      _wfx_cross_messager.sendMessage(
         editorElement.contentWindow,
         _wfx_message_types.REFRESH_TOOLTIP,
         cornerPositionAdjustment
      );
    }
  },
  execute: function(tipData) {
    const iconElement = this.getIconElementForContentType(tipData.contentType);
    if(!iconElement) {
      return;
    }
    const iconElementBoundingRect = iconElement.getBoundingClientRect();
    const placement = tipData.action.placement;
    if (getHeightOfPopup() > 0 && this.checkOverflow()) {
      var newPlacement = tipData.action.good_placement;
      if (iconElementBoundingRect.top < 0 && newPlacement === placement && placement.startsWith("l")) {
        newPlacement = this.getLeftOverflowFixPlacement(placement);
      }
      if (!!placement && !!newPlacement && newPlacement !== placement) {
        this.refreshToolTipOnOverflow(newPlacement,
          iconElementBoundingRect.left,
          iconElementBoundingRect.top,
          iconElementBoundingRect.width,
          iconElementBoundingRect.height);
      }
    }
  },
  getIconElementForContentType: function(contentType) {
    if(contentType === _wfx_content_types.BEACON) {
      return document.querySelector(_wfx_element_selectors.STUDIO_BEACON_CLASS);
    } else if(contentType === _wfx_content_types.SMART_TIP || contentType === _wfx_content_types.TIP) {
      return document.querySelector(_wfx_element_selectors.TIP_INFO_ICON_CLASS);
    } else {
      return null;
    }
  },
  checkOverflow: function() {
    const popoverWidth = getWidthOfPopup();
    const popoverHeight = getHeightOfPopup();
    const left = getLeftOfPopup(), top = getTopOfPopup();
    const documentWidth = document.body.scrollWidth;
    const documentHeight = document.body.scrollHeight;
    return (left < 0 || left + popoverWidth > documentWidth
      || top < 0 || top + popoverHeight > documentHeight);
  }
};

function getHeightOfPopup() {
  const tooltipWrapper = document.querySelector(_wfx_element_selectors.TOOLTIP_WRAPPER_ID);
  return tooltipWrapper && tooltipWrapper.clientHeight;
}

function getWidthOfPopup() {
  const tooltipWrapper = document.querySelector(_wfx_element_selectors.TOOLTIP_WRAPPER_ID);
  return tooltipWrapper && tooltipWrapper.clientWidth;
}

function getLeftOfPopup() {
  const tooltipWrapper = document.querySelector(_wfx_element_selectors.TOOLTIP_WRAPPER_ID);
  return tooltipWrapper && tooltipWrapper.getBoundingClientRect().left;
}

function getTopOfPopup() {
  const tooltipWrapper = document.querySelector(_wfx_element_selectors.TOOLTIP_WRAPPER_ID);
  return tooltipWrapper && tooltipWrapper.getBoundingClientRect().top;
}

function isChromium() {
  window.chrome && typeof window.chrome !== "undefined" ? true : false;
}

function shouldDisplayIconForSmartTip(action) {
  var smtIconActions = [5, 9];
  return smtIconActions.includes(action);
}

function getArrowCoordinates(placement, borderRadius) {
  var popoverWidth = getWidthOfPopup();
  var arrowLeft;
  var arrowTop;
  popHeight = getHeightOfPopup();
  if (placement == null) {
    placement = "b";
  }
  if (placement === "rb") {
    arrowLeft = getArrowLeft(placement);
    arrowTop = popHeight - 3 * getArrowMargin(borderRadius);
  } else if (placement === "r") {
    arrowLeft = getArrowLeft(placement);
    arrowTop = popHeight / 2 - getArrowMargin(borderRadius);
  } else if (placement === "lb") {
    arrowLeft = getArrowLeft(placement);
    arrowTop = popHeight - 3 * getArrowMargin(borderRadius);
  } else if (placement === "l") {
    arrowLeft = getArrowLeft(placement);
    arrowTop = popHeight / 2 - getArrowMargin(borderRadius);
  } else if (placement === "tr" || placement === "br") {
    arrowLeft = popoverWidth - 3 * getArrowMargin(borderRadius);
    arrowTop = getArrowTop(placement);
  } else if (placement === "t" || placement === "b") {
    arrowLeft = popoverWidth / 2 - getArrowMargin(borderRadius);
    arrowTop = getArrowTop(placement);
  } else {
    return;
  }
  return [arrowLeft + "px", arrowTop + "px"];
}

function widthOfTooltip() {
  var screenWidth;
  if (window.innerWidth) {
    screenWidth = window.innerWidth;
  } else {
    screenWidth = document.body.clientWidth;
  }
  if (screenWidth > 640) {
    return "350px";
  } else if (screenWidth > 480) {
    return "300px";
  } else if (screenWidth > 320) {
    return "270px";
  } else {
    return "240px";
  }
}

function getArrowLeft(placement) {
  if (placement.startsWith("r")) {
    return isChromium() ? 1 : 0;
  }
  return isChromium() ? -1 : 0;
}

function getArrowTop(placement) {
  if (placement.startsWith("t")) {
    return isChromium() ? -1 : 0;
  }
  return isChromium() ? 1 : 0;
}

function getArrowMargin(borderRadius) {
  var cornerRadius = borderRadius;
  if (cornerRadius <= 10) {
    return 10;
  }
  return cornerRadius;
}

function edgeGap() {
  return 1;
}

function getArrowHeight(theme) {
  const arrowHeights = {
    classic: 10,
    modern: 12,
    ivory: 25,
  };
  return arrowHeights[theme];
}

function getCustomBeaconHeight() {
  const beaconContainer = document.querySelector(_wfx_element_selectors.STUDIO_BEACON_ID);
  return beaconContainer && beaconContainer.getBoundingClientRect().height;
}

function getCustomBeaconWidth() {
  const beaconContainer = document.querySelector(_wfx_element_selectors.STUDIO_BEACON_ID);
  return beaconContainer && beaconContainer.getBoundingClientRect().width;
}

function getBeaconPlacementLeftAndTop(
  top,
  relRight,
  relBottom,
  left,
  values,
  placement
) {
  var popupLeft;
  var popupTop;
  var beaconWidth = _wfx_beacon_default_animation_width;
  var beaconHeight = _wfx_beacon_default_animation_height;
  
  if (
    getBeaconTheme(values) ===
    _wfx_beacon_animation_type.RADIAL
  ) {
    beaconWidth = _wfx_beacon_radial_animation_half_width;
  } else if (
    getBeaconTheme(values) ===
    _wfx_beacon_animation_type.NEW
  ) {
    beaconWidth = getCustomBeaconWidth();
    beaconHeight = getCustomBeaconHeight();
  }

  if (placement.includes("t")) {
    popupTop = top - _wfx_beacon_icon_height / 4 - beaconHeight / 2;
  } else {
    popupTop = relBottom - _wfx_beacon_icon_height / 4 - getHeightOfPopup() / 2;
  }

  if (placement.includes("l")) {
    popupLeft =
      left - _wfx_beacon_icon_width / 4 - getWidthOfPopup() - beaconWidth;
  } else {
    popupLeft = relRight - _wfx_beacon_icon_width / 4 + beaconWidth;
  }
  
  return [popupLeft + "px", popupTop + "px"];
}

function getPlacementLeftAndTop(
  relTop,
  relRight,
  relBottom,
  relLeft,
  placement,
  engage,
  theme,
  values
) {
  if (placement == null) {
    return null;
  }
  var popHeight = getHeightOfPopup();
  popHeight = Math.max(popHeight, 73);
  var popoverWidth = getWidthOfPopup();
  var eleHeight = relBottom - relTop;
  var eleWidth = relRight - relLeft;
  var popupLeft;
  var popupTop;

  var _isSmtIIcon = false;

  if (
    (values.contentType === "tip" || values.contentType === "smart_tip") &&
    shouldDisplayIconForSmartTip(values.action.action)
  ) {
    _isSmtIIcon = true;
  }
  
  if (values.contentType === _wfx_content_types.BEACON && _wfx_beacon_placements.some((val) => val === placement)) {
  	var _engage = 2 * engage;
    var _top = values.action.top - _engage;
    var _relRight = relRight + _engage;
    var _relBottom = relBottom + _engage;
    var _left = values.action.left - _engage;

    return getBeaconPlacementLeftAndTop(_top, _relRight, _relBottom, _left, values, placement);
  }
  
  if (placement === "rel" && (values.contentType === "tip" || values.contentType === "smart_tip" || values.contentType === "beacon" ||  values.contentType === "validation_tip")) {
    popupLeft = values.action.left + Math.floor(values.action.left_relative / 100 * values.action.width)
    	+ (_isSmtIIcon ? (getIconWidth() / 2) : (values.contentType === "beacon") ? getBeaconWidth(getBeaconTheme(values)) / 2 : 0);
    popupTop  = values.action.top + Math.floor(values.action.top_relative / 100 * values.action.height) - getArrowHeight(theme);
  }else if (placement === "rb") {
    popupLeft = relRight + 2 * engage;
    popupTop = relBottom - popHeight - edgeGap();
  } else if (placement === "r") {
    popupLeft = (relRight + 2 * engage) + (_isSmtIIcon ? 28 : 0);
    popupTop = relTop + eleHeight / 2 - popHeight / 2;
  } else if (placement === "lb") {
    popupLeft = relLeft - 2 * engage - popoverWidth - getArrowHeight(theme);
    popupTop = relBottom - popHeight - edgeGap();
  } else if (placement === "l") {
    popupLeft =
      relLeft -
      2 * engage -
      popoverWidth -
      getArrowHeight(theme) -
      (_isSmtIIcon ? 28 : 0);
    popupTop = relTop + eleHeight / 2 - popHeight / 2;
  } else if (placement === "tl") {
    popupLeft = relLeft + edgeGap();
    popupTop = relTop - popHeight - 2 * engage - getArrowHeight(theme)- (_isSmtIIcon ? 28 : 0);
  } else if (placement === "tr") {
    popupLeft = relRight - popoverWidth - edgeGap();
    popupTop = relTop - popHeight - 2 * engage - getArrowHeight(theme)- (_isSmtIIcon ? 28 : 0);
  } else if (placement === "t") {
    popupLeft = relLeft + eleWidth / 2 - popoverWidth / 2;
    popupTop =
      relTop -
      popHeight -
      2 * engage -
      getArrowHeight(theme) -
      (_isSmtIIcon ? 28 : 0);
    popupTop = (relTop - popHeight - 2 * engage - getArrowHeight(theme)) - (_isSmtIIcon ? 28 : 0);
  } else if (placement === "br") {
    popupLeft = relRight - popoverWidth - edgeGap();
    popupTop = relBottom + 2 * engage + (_isSmtIIcon ? 28 : 0);
  } else if (placement === "b") {
    popupLeft = relLeft + eleWidth / 2 - popoverWidth / 2;
    popupTop = relBottom + 2 * engage + (_isSmtIIcon ? 28 : 0);
  } else if (placement === "lt") {
    popupLeft = relLeft - 2 * engage - popoverWidth - getArrowHeight(theme);
  } else {
    return null;
  }
  return [popupLeft + "px", popupTop + "px"];
 }

/**
 * Logic to render tooltip which is exposed by editabletooltip bundle which is generated from middleware.
 * This function is called from baseGlue
 */

function initiateTip(tipData) {
  var values = JSON.parse(tipData);
  var cornerPositionAdjustment = values.cornerPositionAdjustment;
  var div = document.createElement("div");
  div.innerHTML = values.html.trim();
  // Change this to div.childNodes to support multiple top-level nodes.
  var body = document.getElementsByTagName("BODY")[0];
  body.style.overflow = "hidden";
  if (body.querySelectorAll('[data-wfx-attr="wfx-editor-step-preview"]')[0]) {
    body
      .querySelectorAll('[data-wfx-attr="wfx-editor-step-preview"]')[0]
      .remove();
  }
  body.appendChild(div.firstChild);
  /**
   * Tip with i icon case
   */
  if (
    (values.contentType === "tip" || values.contentType === "smart_tip") &&
    shouldDisplayIconForSmartTip(values.action.action)
  ) {
    document.querySelector(".ico-information").innerHTML = _wfx_smt_icon;
  }
  var schedularForToolTipLoad = setInterval(function () {
    var ele = body.querySelector("#wfx-container-for-tooltip");
    if (ele) {
      if (typeof window.loadReactComponents !== "undefined") {
        clearInterval(schedularForToolTipLoad);
        loadReactComponents(window);

        // after rendering alter the toolbox container element position
        var toolBox, errorMsg;
        if (!document.querySelector("#wfx-froala-container-main")) {
          var container = document.createElement("div");
          container.id = "wfx-froala-container-main";
          container.classList.add("wfx-studio-toolbar-container");
          container.classList.add("hide");
          document.body.appendChild(container);

          toolBox = document.createElement("div");
          toolBox.id = "wfx-froala-toolbar-container";
          container.appendChild(toolBox);

          errorMsg = document.createElement("div");
          errorMsg.id = "wfx-froala-error-msg-container";
          container.appendChild(errorMsg);
        }
        toolBox = document.querySelector("#wfx-froala-toolbar-container");
        errorMsg = document.querySelector("#wfx-froala-error-msg-container");

        if (/^(tl|t|tr)$/gi.test(values.action.placement)) {
          toolBox.before(errorMsg);
        } else {
          toolBox.after(errorMsg);
        }
        window.WfxComponents.editableTooltipComponentController.unmountComponentAtNode(
          ele
        );
        window.WfxComponents.editableTooltipComponentController.render(ele, {
          purpose: values.action.description_md,
          description: values.action.note_md,
          placement: values.action.placement,
          theme:
            values.theme === undefined
              ? { tip_theme_type: "classic" }
              : values.theme,
          isBackButtonEnabled: values.action.back_button,
          contentType: values.contentType,
          validationError: values.action.validation_errors_md,
          completionActions: values.action.completion_actions,
          limit: values.limit,
          beaconCustomisation: values.action.step_beacon_customisation,
        });
      }
    }
  }, 0);
  var widthOfTip = widthOfTooltip();
  var tooltipWrapper = document.querySelector(_wfx_element_selectors.TOOLTIP_WRAPPER_ID);
  tooltipWrapper && (tooltipWrapper.style.maxWidth = widthOfTip);
  if(!cornerPositionAdjustment){
    recalibrateTip(tipData);
  }
  if (values.contentType === "beacon") {
    attachClickHandler();
  }
}

function initiateEventPropPopup(position) {
 	if (typeof window.loadReactComponents !== "undefined") {
 		if(document.querySelector("#wfx-flow-tip-step-snap"))
 			document.querySelector("#wfx-flow-tip-step-snap").remove();
		if(window.parent.document.querySelector("#_wfx-preview-iframe")){
			window.parent.document.querySelector("#_wfx-preview-iframe").style.backgroundColor = "transparent";
 			window.parent.document.querySelector("#_wfx-preview-iframe").style.backdropFilter = "none";
		}	
		if(document.querySelector(".wfx-studio-ua-popup-container")){
			document.querySelector(".wfx-studio-ua-popup-container").remove();
		}
    	loadReactComponents(window);
    	var outerDiv = document.createElement("div");
		outerDiv.classList.add("wfx-studio-ua-popup-container");
		document.body.appendChild(outerDiv);
		
		window.WfxComponents &&
		window.WfxComponents.userActionPopupComponentController &&
		window.WfxComponents.userActionPopupComponentController.render(outerDiv, {position: position});
	}
   	
}

function attachClickHandler() {
  var _wfx_beacon = document.querySelector(".wfx-studio-new-beacon");
  _wfx_beacon.removeEventListener("click", handleBeaconClick);
  _wfx_beacon.addEventListener("click", handleBeaconClick);
}

function handleBeaconClick(event) {
  var elementToattach = document.querySelector(".wfx-color-picker-wrapper");
  window.WfxComponents.editableBeaconColorController.render(
    elementToattach,
    {}
  );
  var _wrapper = document.querySelector(".wfx-color-picker-wrapper");
  var beaconPostion = event.target.getBoundingClientRect();
  var _clientWidth = document.documentElement.clientWidth;
  _wrapper.style.top =
    beaconPostion.top > 95
      ? beaconPostion.top - 96 + "px"
      : beaconPostion.top + 96 + "px";

  _wrapper.style.left =
    beaconPostion.left <= 233
      ? "233px"
      : _clientWidth - beaconPostion.left < 233
      ? beaconPostion.left - (233 - (_clientWidth - beaconPostion.left))
      : beaconPostion.left;
}

function recalibrateTip(tipData, values) {
  var body = document.getElementsByTagName("BODY")[0];
  var values = JSON.parse(tipData);
  var schedularForPostTooltipLoad = setInterval(function () {
    var froalaRendered = document.getElementsByClassName(
      "fr-element fr-view"
    )[0];
    if (froalaRendered) {
      clearInterval(schedularForPostTooltipLoad);
      var borderRadius =
        (values.theme &&
          values.theme[values.theme.tip_theme_type + "_tip_corner_radius"]) ||
        4;
      var wrapperPosition = getPlacementLeftAndTop(
        values.action.top,
        values.action.left + values.action.width,
        values.action.top + values.action.height,
        values.action.left,
        values.action.placement,
        2,
        values.theme.tip_theme_type,
        values
      );
      var popup = body.querySelector("#wfx-flow-tip-step-snap");
      if (popup) {
        wrapperPosition && (popup.style.left = wrapperPosition[0]);
        wrapperPosition && (popup.style.top = wrapperPosition[1]);
      }
      //This is an array 0=> left, 1 =>top
      var arrowLeftAndTop = getArrowCoordinates(
        values.action.placement,
        borderRadius
      );
      var arrowElement = document.querySelector("#wfx-tooltip-arrow");
      if (arrowElement && arrowLeftAndTop) {
        arrowLeftAndTop[0] && (arrowElement.style.left = arrowLeftAndTop[0]);
        arrowLeftAndTop[1] && (arrowElement.style.top = arrowLeftAndTop[1]);
      }
      _wfx_corner_position_handler.execute(values);
      checkOverlap();
    }
  }, 0);
}

function checkOverlap() {
  var tipElement = document.querySelector("#wfx-flow-tip-step-snap");
  var editorElement = window.top.document.getElementById("wfx-editor-iframe");
  if (tipElement && editorElement) {
    var tipRect = tipElement.getBoundingClientRect();
    var editorRect = editorElement.getBoundingClientRect();
    if (
      tipRect.x < editorRect.x + editorRect.width &&
      tipRect.x + tipRect.width > editorRect.x &&
      tipRect.y < editorRect.y + editorRect.height &&
      tipRect.height + tipRect.y > editorRect.y
    ) {
      let left = tipRect.x >= window.innerWidth / 2;
      window.top.postMessage(
        "$#@wfx_editor_shift:" + JSON.stringify(left),
        "*"
      );
    }
  }
}

function getBeaconWidth(theme) {
	switch(theme){
		case _wfx_beacon_animation_type.RADIAL: return _wfx_beacon_width.RADIAL;
		case _wfx_beacon_animation_type.NEW: return _wfx_beacon_width.NEW;
		case _wfx_beacon_animation_type.RIPPLE: return _wfx_beacon_width.RIPPLE;
		case _wfx_beacon_animation_type.SPECKLE: return _wfx_beacon_width.SPECKLE;
	}
	return 0;
}

function getBeaconTheme(values){
	var _wfx_beacon_theme = values.action && values.action.step_beacon_customisation && values.action.step_beacon_customisation.beacon_style;
	return (_wfx_beacon_theme) ? _wfx_beacon_theme : (values.theme && values.theme.beacon_animation_type);
}

function getIconWidth(){
	var _wfx_tip_info_icon = document.querySelector(_wfx_element_selectors.TIP_INFO_ICON_CLASS);
	return _wfx_tip_info_icon && _wfx_tip_info_icon.clientWidth; 
}

window.getPlacementLeftAndTop = getPlacementLeftAndTop;
window.getArrowCoordinates = getArrowCoordinates;
window.getWidthOfPopup = getWidthOfPopup;
window.getHeightOfPopup = getHeightOfPopup;
window.initiateTip = initiateTip;
window.initiateEventPropPopup = initiateEventPropPopup;
