var crypty = "$#@";
var delimeter = ":";
var actionType = "popup_template";

window.onmessage = function (event) {
  validateAndProcess(event["data"]);
}

function validateAndProcess(message) {
  if (message == null || !message.startsWith(crypty + actionType)) {
    return;
  }
  var delIndex = message.indexOf(delimeter, crypty.length);
  var content = message.substring(delIndex + 1);
  renderPopup(content);
}

function renderPopup (data) {
  var contentWindow = window;

  var interval = contentWindow.setInterval(function () {
    if (typeof contentWindow.loadReactComponents !== "undefined") {
      contentWindow.clearInterval(interval);
      contentWindow.loadReactComponents(contentWindow);
      var elementId = "popup-container-div-element";
      var ele = document.getElementById(elementId);
      if(ele){
        contentWindow.WfxComponents.editablePopupComponentController.unmountComponentAtNode(ele);
      }else{
        ele = document.createElement('div');
	    ele.setAttribute("id", elementId);
      	document.body.appendChild(ele);
      }
      contentWindow.WfxComponents.editablePopupComponentController.render(ele, {
        templateData: JSON.parse(data)
      });
    }
  }, 0);

}